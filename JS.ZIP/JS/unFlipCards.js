export default function unFlipCards (firstCard, secondCard) {
    firstCard.classList.remove('flip');
    secondCard.classList.remove('flip'); 
}