import shuffle from "./shuffle.js";
import countingMoves from "./countingMoves.js";
import checkForMatch from "./checkForMatch.js";
import showModal from "./showModal.js";
import { firstCard, secondCard, counter, setFlippedCard } from "./setFlippedCard.js";

const cards = document.querySelectorAll('.cards');
shuffle(cards);

function cardClickHandler () {
    setFlippedCard(this);
    let promise = checkForMatch(firstCard, secondCard);
    promise.then(() => {
        const amountOfHiddenCards = document.getElementsByClassName('hide').length;
        if (amountOfHiddenCards === 32) {
            showModal(counter);
        }
    })
    countingMoves(counter);
    
}

cards.forEach(card => card.addEventListener('click', cardClickHandler));