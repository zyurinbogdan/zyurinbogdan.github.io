export default function removeCards (firstCard, secondCard) {
    firstCard.classList.add('hide');
    secondCard.classList.add('hide'); 
}