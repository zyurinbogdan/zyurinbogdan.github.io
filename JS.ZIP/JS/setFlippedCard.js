import unFlipCards from "./unFlipCards.js";
let firstCard;
let secondCard;
let counter = 0
function setFlippedCard (targetCard) {
    let countOfFlippedCards = document.getElementsByClassName('flip').length;

    targetCard.classList.add('flip');
    if (firstCard !== targetCard && secondCard !== targetCard ) {
        if (countOfFlippedCards === 0 ) {
            firstCard = targetCard;
        } else if (countOfFlippedCards === 1) {
            secondCard = targetCard;
            counter++;
        } else if (countOfFlippedCards = 2) {
            unFlipCards(firstCard, secondCard);
            firstCard = targetCard;
        }
    }
}

export {firstCard, secondCard, counter, setFlippedCard};